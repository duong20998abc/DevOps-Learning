How to run:
OS: ubuntu
install : sudo apt install npm
          sudo apt install nodejs

Run project with:

npm install
node server.js DB_HOST=172.17.0.2 DB_USER=root DB_PASS=a123456

require: mysql is running on: 172.17.0.2 with:
mysql user=root
mysql root password= a123456
(run docker mysql or RDS)

Run Tag version
Ready for deploy

---------------------------
Helm Chart:
Package chart: helm package mychart
Deploy chart:  helm install myapp mychart-0.1.0.tgz -n ns1 --create-namespace
Get deployed:  kubectl get all -n ns1
